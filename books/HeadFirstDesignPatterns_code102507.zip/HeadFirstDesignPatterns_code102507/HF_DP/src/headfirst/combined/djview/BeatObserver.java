package headfirst.combined.djview;
  
public interface BeatObserver {
	void updateBeat();
}
