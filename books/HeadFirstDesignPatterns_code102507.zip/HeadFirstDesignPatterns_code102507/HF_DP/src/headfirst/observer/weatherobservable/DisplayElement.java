package headfirst.observer.weatherobservable;

public interface DisplayElement {
	public void display();
}
